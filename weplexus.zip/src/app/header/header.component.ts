import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AuthenticationService } from '../authentication.service';
import {  Router, Route } from '@angular/router';
import { AppComponent } from '../app.component';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  // constructor(private cookieService: CookieService, private globalComponent: AppComponent, private router: Router) { }
  // tslint:disable-next-line:max-line-length
  constructor(private cookieService: CookieService, private auth: AuthenticationService, private globalComponent: AppComponent, private router: Router) { }
  userId = this.cookieService.get('userId');
  userEmail = this.cookieService.get('userEmail');
  userFirstName = this.cookieService.get('userFirstName');
  userLastName = this.cookieService.get('userLastName');
  userType = this.cookieService.get('userType');
  authCode = this.cookieService.get('authCode');
  privateKey = this.cookieService.get('privateKey');
  log_type: any;
  log_value: any;

  ngOnInit() {
      // login parameters
      this.log_type =  this.globalComponent.replaceForwardByDollar(this.globalComponent.convertEncrypt('user-profile'));
      this.log_value =  this.globalComponent.replaceForwardByDollar(this.globalComponent.convertEncrypt('default'));
  }
  // user logout
  userLogOut(log_type, log_value) {
    this.auth.logOut(log_type, log_value);

    this.userId = this.cookieService.get('userId');
    this.userEmail = this.cookieService.get('userEmail');
    this.userFirstName = this.cookieService.get('userFirstName');
    this.userLastName = this.cookieService.get('userLastName');
    this.userType = this.cookieService.get('userType');
    this.authCode = this.cookieService.get('authCode');
    this.privateKey = this.cookieService.get('privateKey');
  }
}
