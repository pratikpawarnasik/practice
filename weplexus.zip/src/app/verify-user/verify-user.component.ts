import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-verify-user',
  templateUrl: './verify-user.component.html',
  styleUrls: ['./verify-user.component.scss']
})
export class VerifyUserComponent implements OnInit {
  private sub: any;
  verifyCode: any;
  Response: any;
  responseMessage: any;
  constructor( private userService: UserServiceService, private router: Router, private route: ActivatedRoute) {}

// Initialization
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.verifyCode = params['verify_code']; // (+) converts string 'id' to a number
      this.getUserData(this.verifyCode);
    });
  }
   // Get user data
   getUserData(verifyCodeId) {
    this.userService.url_verifyUserApi(verifyCodeId).
    subscribe(
      data => {
          this.Response = data;
        if (this.Response.status === 200) {
          this.responseMessage = this.Response.message;
          alert(this.responseMessage);
        } else {
          this.responseMessage = this.Response.message;
          alert(this.responseMessage);
        }
      },
      error => console.log( 'Error :: ' + error )
      );
  }
}
