import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { AppComponent } from '../app.component';
import * as $ from 'jquery';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  title = 'User Registration';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  employees: any;
  employeesdata: any;
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private userService: UserServiceService, private globalComponent: AppComponent) {

  // Register Initialization
  this.registerForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          userType: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          mobileNumber: ['', Validators.required],
          password: ['', [Validators.required, Validators.minLength(6)]]
        });
   }
  // initialization
    ngOnInit() {
          $('#chkMobileNumberId').hide();
          this.responseMessage = '';
      }
  // isMobileNumber
      public isMobileNumber(mobileNumber) {
        if (mobileNumber !== '') {
          const regex = /^[7-9][0-9]{9}$/;
          return regex.test(mobileNumber);
        }
        return true;
      }
    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    // User Register
    onSubmit() {
      this.submitted = true;
      this.responseMessage = '';
      if (this.isMobileNumber(this.registerForm.controls.mobileNumber.value) === true) {
        $('#chkMobileNumberId').hide();
         // stop here if form is invalid
        if (this.registerForm.invalid) {
              return false;
          }
        const firstName = this.globalComponent.convertEncrypt(this.registerForm.controls.firstName.value);
        const lastName = this.globalComponent.convertEncrypt(this.registerForm.controls.lastName.value);
        const email = this.globalComponent.convertEncrypt(this.registerForm.controls.email.value);
        const mobileNumber = this.globalComponent.convertEncrypt(this.registerForm.controls.mobileNumber.value);
        const userType = this.globalComponent.convertEncrypt(this.registerForm.controls.userType.value);
        const password = this.globalComponent.convertEncrypt(this.registerForm.controls.password.value);

        const formData: FormData = new FormData();
        formData.append('firstName', firstName);
        formData.append('lastName', lastName);
        formData.append('email', email);
        formData.append('mobileNumber', mobileNumber);
        formData.append('userType', userType);
        formData.append('password', password);
        this.userService.url_registerUserApi(formData).
              subscribe(
                resultArray => {
                  this.Response = resultArray;
                  if (this.Response.status === 200) {
                    alert(this.Response.message);
                    this.submitted = false;
                    this.registerForm.reset();
                  } else {
                    this.responseMessage = this.Response.message;
                  }
                },
                error => console.log('Error :: ' + error)
              );
          } else {
              $('#chkMobileNumberId').show();
              alert('Please enter valid mobile number.');
          }
    }
}
