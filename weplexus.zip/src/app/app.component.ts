import { Component, ViewChild, AfterViewInit, OnInit } from '@angular/core';
import * as CryptoJS from 'crypto-js';
// import { HeaderComponent } from './header/header.component';
 import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    title = 'app';
    key: any = CryptoJS.enc.Hex.parse('0123456789abcdef0123456789abcdef');
    iv: any = CryptoJS.enc.Hex.parse('abcdef9876543210abcdef9876543210');
    encrypted: any;
    plaintext: any;
    dplaintext: any;

   // @ViewChild(HeaderComponent) header;
    constructor(private cookieService: CookieService) {}
   // constructor() {}

   ngOnInit() {
      //  this.header.userId = this.cookieService.get('userId');
      //  this.header.userEmail = this.cookieService.get('userEmail');
      //  this.header.userFirstName = this.cookieService.get('userFirstName');
      //  this.header.userLastName = this.cookieService.get('userLastName');
      //  this.header.userType = this.cookieService.get('userType');
      //  this.header.authCode = this.cookieService.get('authCode');
      //  this.header.privateKey = this.cookieService.get('privateKey');
    }
    // Convert Encrypt
    public convertEncrypt(text, key_value: any = null) {
        if (key_value != null) {
          key_value = this.convertDecrypt(key_value);
          key_value = CryptoJS.enc.Hex.parse(key_value);
          this.plaintext = CryptoJS.AES.encrypt(text, key_value, { iv: this.iv, padding: CryptoJS.pad.ZeroPadding });
        } else {
          this.plaintext = CryptoJS.AES.encrypt(text, this.key, { iv: this.iv, padding: CryptoJS.pad.ZeroPadding });
        }
        return this.plaintext.toString();
      }

    // Convert Decrypt
    public convertDecrypt(text, key_value: any = null) {
          if (key_value != null) {
            key_value = this.convertDecrypt(key_value);
            key_value = CryptoJS.enc.Hex.parse(key_value);
            this.dplaintext = CryptoJS.AES.decrypt(text, key_value, { iv: this.iv, padding: CryptoJS.pad.ZeroPadding });
            this.dplaintext = CryptoJS.enc.Utf8.stringify(this.dplaintext);
          } else {
            this.dplaintext = CryptoJS.AES.decrypt(text, this.key, { iv: this.iv, padding: CryptoJS.pad.ZeroPadding });
            this.dplaintext = CryptoJS.enc.Utf8.stringify(this.dplaintext);
          }
          return this.dplaintext.toString();
      }
      // replace Dollar By Forward
      public replaceDollarByForward(text) {
        const user_id = text.replace(/\$/g, '/');
        const repl_output = user_id.replace(/\!/g, '=');
        return repl_output;
      }
      // replace Forward By Dollar
      public replaceForwardByDollar(text) {
        const user_id = text.replace(/\//g, '$');
        const repl_output = user_id.replace(/\=/g, '!');
        return repl_output;
      }
}
