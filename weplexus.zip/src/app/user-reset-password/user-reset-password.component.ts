import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-user-reset-password',
  templateUrl: './user-reset-password.component.html',
  styleUrls: ['./user-reset-password.component.scss']
})
export class UserResetPasswordComponent implements OnInit {

  title = 'User Reset Password';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  private sub: any;
  resetCode: any;
  userId: any;
  resetPasswordForm: FormGroup;
  submitted = false;

  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private userService: UserServiceService, private globalComponent: AppComponent, private router: Router, private route: ActivatedRoute) {
  this.resetPasswordForm = this.formBuilder.group({
          password: ['', [Validators.required, Validators.minLength(6)]],
          conf_password: ['', [Validators.required, Validators.minLength(6)]]
        });
   }
// initialization
ngOnInit() {
  $('#reset_frm').hide();
  this.responseMessage = '';
  this.sub = this.route.params.subscribe(params => {
    this.resetCode = params['reset_code']; // (+) converts string 'id' to a number
  });
  this.checkResetPassLink(this.resetCode);
}
// convenience getter for easy access to form fields
get f() { return this.resetPasswordForm.controls; }

// Check Reset Password Link
checkResetPassLink(resetCode) {
  this.responseMessage = '';

  this.userService.url_checkResetPassLinkUserApi(resetCode).
        subscribe(
          resultArray => {
            this.Response = resultArray;
            if (this.Response.status === 200) {
              this.userId = this.Response.data.user_id;
              $('#reset_frm').show();
            } else {
              this.responseMessage = this.Response.message;
              alert(this.responseMessage);
              $('#reset_frm').hide();
              this.router.navigateByUrl('/');
            }
          },
          error => console.log('Error :: ' + error)
        );
    }
// reset form submit
onSubmit() {
    this.submitted = true;
    this.responseMessage = '';
    // stop here if form is invalid
    if (this.resetPasswordForm.invalid) {
          return false;
      }
    const user_id = this.userId;
    const reset_code = this.resetCode;
    const conf_password = this.globalComponent.convertEncrypt(this.resetPasswordForm.controls.conf_password.value);
    const password = this.globalComponent.convertEncrypt(this.resetPasswordForm.controls.password.value);

    const formData: FormData = new FormData();
    formData.append('user_id', user_id);
    formData.append('reset_code', reset_code);
    formData.append('password', password);
    formData.append('confirmPassword', conf_password);
    this.userService.url_forgetResetPasswordUserApi(formData).
          subscribe(
            resultArray => {
              this.Response = resultArray;
              if (this.Response.status === 200) {
                this.responseMessage = this.Response.message;
                alert(this.responseMessage);
                this.submitted = false;
                this.resetPasswordForm.reset();
              } else {
                this.responseMessage = this.Response.message;
                alert(this.Response.message);
              }
            },
            error => console.log('Error :: ' + error)
        );
  }
}
