import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { UserServiceService } from '../user-service.service';
import { Router, Route, ActivatedRoute} from '@angular/router';
import { AppComponent } from '../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  title = 'User Login';
  title_forgot = 'User Forgot Password';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  employees: any;
  employeesdata: any;
  loginForm: FormGroup;
  forgotForm: FormGroup;
  submitted = false;
  sub: any;
  log_type: any;
  log_value: any;
  cookieUserIdExists: boolean = this.cookieService.check('userId');
  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private userService: UserServiceService, private globalComponent: AppComponent, private cookieService: CookieService, private router: Router, private routes: ActivatedRoute) {

  this.loginForm = this.formBuilder.group({
          userName: ['', [Validators.required]],
          password: ['', [Validators.required, Validators.minLength(6)]]
        });
  this.forgotForm = this.formBuilder.group({
          email: ['', [Validators.required]]
        });
   }
// initialization
ngOnInit() {
  this.sub = this.routes.params.subscribe(params => {
    this.log_type = this.globalComponent.convertDecrypt(this.globalComponent.replaceDollarByForward(params['type']));
    this.log_value = params['value'];
  });
  if (this.cookieUserIdExists === true) {
    this.router.navigate(['/']);
  }
  $('#chkUserNameId').hide();
  $('#forgot_frm').hide();
  this.responseMessage = '';
}
// Check Valid User Name
public isCheckValidUserName(userName) {
    const checkFirstChar = this.isMobileNumber(userName.charAt(0));
    const isCheck = this.isMobileNumber(userName.charAt(0));
    if (userName !== '') {
      if (checkFirstChar === false) {
        const regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return regex.test(userName);
      } else {
        const regex = /^[7-9][0-9]{9}$/;
        return regex.test(userName);
      }
    } else {
      return false;
    }
}
// Mobile Number Validation
public isMobileNumber(mobileNumber) {
    const regex = /^[0-9]{1}$/;
    return regex.test(mobileNumber);
}
public changeFrm(status) {
    $('#forgot_frm').show();
    $('#add_frm').hide();
}
public changeLoginFrm(status) {
    $('#forgot_frm').hide();
    $('#add_frm').show();
}
// convenience getter for easy access to form fields
get f() { return this.loginForm.controls; }
// convenience getter for easy access to form fields
get ff() { return this.forgotForm.controls; }

// User Login Form
onSubmit() {
this.submitted = true;
this.responseMessage = '';
if (this.isCheckValidUserName(this.loginForm.controls.userName.value) === true) {
$('#chkUserNameId').hide();
 // stop here if form is invalid
if (this.loginForm.invalid) {
      return false;
  }
const userName = this.globalComponent.convertEncrypt(this.loginForm.controls.userName.value);
const password = this.globalComponent.convertEncrypt(this.loginForm.controls.password.value);

const formData: FormData = new FormData();
formData.append('userName', userName);
formData.append('password', password);
this.userService.url_loginUserApi(formData).
      subscribe(
        resultArray => {
          this.Response = resultArray;
          if (this.Response.status === 200) {
            this.submitted = false;
            // tslint:disable-next-line:max-line-length
            const sessId = this.globalComponent.replaceForwardByDollar(this.Response.data.user_id);
            this.cookieService.set('userId', sessId);
            this.cookieService.set('userEmail', this.Response.data.email);
            this.cookieService.set('userFirstName', this.Response.data.first_name);
            this.cookieService.set('userLastName', this.Response.data.last_name);
            this.cookieService.set('userType', this.Response.data.user_type);
            this.cookieService.set('authCode', this.globalComponent.replaceForwardByDollar(this.Response.data.auth_code));
            this.cookieService.set('privateKey', this.globalComponent.replaceForwardByDollar(this.Response.data.private_key));
            this.loginForm.reset();
            // this.router.navigateByUrl('/headerComponent', { skipLocationChange: true });
            // this.router.navigate(['/']);
            alert(this.log_type);
            switch (this.log_type) {
              case 'verify-invitation':
              this.router.navigate(['/verify_invite_classroom_member/' + this.log_value]);
                break;
              default:
              this.router.navigate(['/userProfile/' + sessId]);
              break;
            }
          } else {
            this.responseMessage = this.Response.message;
          }
        },
        error => console.log('Error :: ' + error)
      );
   } else {
    $('#chkUserNameId').show();
  }
}
// Forgot Password Form
onForgotSubmit() {
  this.submitted = true;
  this.responseMessage = '';
  $('#chkUserNameId').hide();
   // stop here if form is invalid
  if (this.forgotForm.invalid) {
        return false;
    }
  const email = this.globalComponent.convertEncrypt(this.forgotForm.controls.email.value);

  const formData: FormData = new FormData();
  formData.append('email', email);
  this.userService.url_forgetPasswordUserApi(formData).
        subscribe(
          resultArray => {
            this.Response = resultArray;
            if (this.Response.status === 200) {
              alert(this.Response.message);
              this.submitted = false;
              this.forgotForm.reset();
            } else {
              this.responseMessage = this.Response.message;
            }
          },
          error => console.log('Error :: ' + error)
        );
  }
}
