import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from '../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

  title = 'User Change Password';
  Response: any;
  splitted: any;
  successMessage: any;
  errorMessage: any;
  status: any;
  private sub: any;
  userId: any;
  authCode: any;
  privateKey: any;
  changePasswordForm: FormGroup;
  submitted = false;

  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private userService: UserServiceService, private globalComponent: AppComponent, private router: Router, private route: ActivatedRoute, private cookieService: CookieService) {
  this.changePasswordForm = this.formBuilder.group({
          old_password: ['', Validators.required],
          password: ['', [Validators.required, Validators.minLength(6)]],
          conf_password: ['', [Validators.required, Validators.minLength(6)]]
        });
   }
// initialization
ngOnInit() {
  this.successMessage = '';
  this.errorMessage = '';
  this.sub = this.route.params.subscribe(params => {
    this.userId = params['userId']; // (+) converts string 'id' to a number
  });
  this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
  this.authCode = this.cookieService.get('authCode');
}
// convenience getter for easy access to form fields
get f() { return this.changePasswordForm.controls; }

// Change Password Form
onSubmit() {
      this.submitted = true;
      this.successMessage = '';
      this.errorMessage = '';
      // stop here if form is invalid
      if (this.changePasswordForm.invalid) {
            return false;
        }
      const user_id = this.userId;
      const old_password = this.globalComponent.convertEncrypt(this.changePasswordForm.controls.old_password.value);
      const conf_password = this.globalComponent.convertEncrypt(this.changePasswordForm.controls.conf_password.value);
      const password = this.globalComponent.convertEncrypt(this.changePasswordForm.controls.password.value);

      const formData: FormData = new FormData();
      formData.append('user_id', user_id);
      formData.append('authCode', this.authCode);
      formData.append('privateKey', this.privateKey);
      formData.append('oldPassword', old_password);
      formData.append('newPassword', password);
      formData.append('confirmPassword', conf_password);
      this.userService.url_changePasswordUserApi(formData).
            subscribe(
              resultArray => {
                this.Response = resultArray;
                if (this.Response.status === 200) {
                  this.errorMessage = '';
                  this.successMessage = this.Response.message;
                  alert(this.successMessage);
                  this.submitted = false;
                  this.changePasswordForm.reset();
                } else {
                  this.successMessage = '';
                  this.errorMessage = this.Response.message;
                }
              },
              error => console.log('Error :: ' + error)
            );
  }
}
