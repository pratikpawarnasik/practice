import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { AppComponent } from '../app.component';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import * as $ from 'jquery';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {
  title = 'Update User Profile';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  userId: any;
  userDetails: any;
  employeesdata: any;
  userProfileForm: FormGroup;
  submitted = false;
  private sub: any;
  authCode: any;
  privateKey: any;

// tslint:disable-next-line:max-line-length
constructor(private formBuilder: FormBuilder, private userService: UserServiceService, private globalComponent: AppComponent, private router: Router, private route: ActivatedRoute, private cookieService: CookieService) {
 // User Profile initialization
  this.userProfileForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          lastName: ['', Validators.required],
          userType: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          mobileNumber: ['', Validators.required]
        });
   }
 // initialization
  ngOnInit() {
      $('#chkMobileNumberId').hide();
      this.responseMessage = '';
      this.sub = this.route.params.subscribe(params => {
        this.userId = params['userId']; // (+) converts string 'id' to a number
      });
      this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
      this.authCode = this.cookieService.get('authCode');
      this.getSingleUserData(this.userId, this.authCode);
  }
  // Mobile no validation
  public isMobileNumber(mobileNumber) {
    if (mobileNumber !== '') {
      const regex = /^[7-9][0-9]{9}$/;
      return regex.test(mobileNumber);
    }
    return true;
  }

  // Get user data
    getSingleUserData(userId, authCode) {
      this.userService.url_getProfileDetailsUserApi(userId, authCode).
      subscribe(
        data => {
          this.Response = data;
          if (this.Response.status === 200) {
            // tslint:disable-next-line:max-line-length
            this.userProfileForm = this.formBuilder.group({
              firstName: [this.globalComponent.convertDecrypt(this.Response.data.first_name, this.privateKey), Validators.required],
              lastName: [this.globalComponent.convertDecrypt(this.Response.data.last_name, this.privateKey), Validators.required],
              email: [this.globalComponent.convertDecrypt(this.Response.data.email), [Validators.required, Validators.email]],
              userType: [this.Response.data.user_type, [Validators.required]],
              mobileNumber: [this.globalComponent.convertDecrypt(this.Response.data.mobile_no), Validators.required]
            });
          } else {
            this.userDetails = [];
            this.responseMessage = this.Response.message;
          }
        },
        error => console.log( 'Error :: ' + error )
        );
    }
  // convenience getter for easy access to form fields
  get f() { return this.userProfileForm.controls; }

 // User Profile Form
  onSubmit() {
    this.submitted = true;
    this.responseMessage = '';
    if (this.isMobileNumber(this.userProfileForm.controls.mobileNumber.value) === true) {
      $('#chkMobileNumberId').hide();
      // stop here if form is invalid
      if (this.userProfileForm.invalid) {
            return false;
        }
      const firstName = this.globalComponent.convertEncrypt(this.userProfileForm.controls.firstName.value);
      const lastName = this.globalComponent.convertEncrypt(this.userProfileForm.controls.lastName.value);
      const email = this.globalComponent.convertEncrypt(this.userProfileForm.controls.email.value);
      const userType = this.globalComponent.convertEncrypt(this.userProfileForm.controls.userType.value);
      const mobileNumber = this.globalComponent.convertEncrypt(this.userProfileForm.controls.mobileNumber.value);

      const formData: FormData = new FormData();
      formData.append('user_id', this.userId);
      formData.append('firstName', firstName);
      formData.append('lastName', lastName);
      formData.append('authCode', this.authCode);
      formData.append('privateKey', this.privateKey);
      formData.append('email', email);
      formData.append('userType', userType);
      formData.append('mobileNumber', mobileNumber);
      this.userService.url_updateProfileUserApi(formData).
            subscribe(
              resultArray => {
                this.Response = resultArray;
                if (this.Response.status === 200) {
                  alert(this.Response.message);
                  this.userDetails = this.Response.data;
                  this.submitted = false;
                  this.getSingleUserData(this.userId, this.authCode);
                } else {
                  this.responseMessage = this.Response.message;
                }
              },
              error => console.log('Error :: ' + error)
            );
        } else {
          $('#chkMobileNumberId').show();
          alert('Please enter valid mobile number.');
        }
  }
}
