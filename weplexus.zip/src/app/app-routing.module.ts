import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { ClassroomComponent } from './ClassRoom/classroom/classroom.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { VerifyUserComponent } from './verify-user/verify-user.component';
import { UserResetPasswordComponent } from './user-reset-password/user-reset-password.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AuthenticationService } from './authentication.service';
import { UserCreateBlogComponent } from './Blog/user-create-blog/user-create-blog.component';
import { ClassroomJoinRequestComponent } from './ClassRoom/classroom-join-request/classroom-join-request.component';
import { UserClassroomDetailsComponent } from './ClassRoom/user-classroom-details/user-classroom-details.component';
import { SingleUserClassroomComponent } from './ClassRoom/single-user-classroom/single-user-classroom.component';
import { InvitePrivateClassroomUserComponent } from './ClassRoom/invite-private-classroom-user/invite-private-classroom-user.component';
import { VerifyInviteMemberComponent } from './ClassRoom/verify-invite-member/verify-invite-member.component';

const routes: Routes = [
  { path : 'userRegistration' , component: UserComponent},
  { path : 'userProfile/:userId' , component: UserProfileComponent, canActivate: [AuthenticationService]},
  { path : 'headerComponent' , component: HeaderComponent},
  { path : 'contactUs' , component: ContactUsComponent},
  { path : 'aboutUs' , component: AboutUsComponent},
  { path : 'login/:type/:value' , component: LoginComponent},
  { path : 'verify_user/:verify_code' , component: VerifyUserComponent},
  { path : 'reset_user_password/:reset_code' , component: UserResetPasswordComponent},
  { path : 'change_user_password/:userId' , component: ChangePasswordComponent, canActivate: [AuthenticationService]},
  { path : 'user_create_blog' , component: UserCreateBlogComponent, canActivate: [AuthenticationService]},
  { path : 'user_create_classroom' , component: ClassroomComponent, canActivate: [AuthenticationService]},
  { path : 'user_classroom_join_request' , component: ClassroomJoinRequestComponent, canActivate: [AuthenticationService]},
  { path : 'user_classroom_details/:classroomId' , component: UserClassroomDetailsComponent, canActivate: [AuthenticationService]},
  { path : 'user_all_classroom' , component: SingleUserClassroomComponent, canActivate: [AuthenticationService]},
  { path : 'invite_classroom_user/:classroomId' , component: InvitePrivateClassroomUserComponent, canActivate: [AuthenticationService]},
  // tslint:disable-next-line:max-line-length
  { path : 'verify_invite_classroom_member/:uniqueCode' , component: VerifyInviteMemberComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [
        UserComponent,
        UserProfileComponent,
        ClassroomComponent,
        ContactUsComponent,
        AboutUsComponent,
        HeaderComponent,
        LoginComponent,
        VerifyUserComponent,
        UserResetPasswordComponent,
        ChangePasswordComponent,
        UserCreateBlogComponent,
        ClassroomJoinRequestComponent,
        UserClassroomDetailsComponent,
        SingleUserClassroomComponent,
        InvitePrivateClassroomUserComponent,
        VerifyInviteMemberComponent
  ];
