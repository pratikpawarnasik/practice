import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleUserClassroomComponent } from './single-user-classroom.component';

describe('SingleUserClassroomComponent', () => {
  let component: SingleUserClassroomComponent;
  let fixture: ComponentFixture<SingleUserClassroomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingleUserClassroomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleUserClassroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
