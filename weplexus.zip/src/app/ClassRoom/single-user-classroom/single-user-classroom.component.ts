import { Component, OnInit , ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClassroomServiceService } from '../services/user-classroom.service';
import { Router, Route } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-single-user-classroom',
  templateUrl: './single-user-classroom.component.html',
  styleUrls: ['./single-user-classroom.component.scss']
})
export class SingleUserClassroomComponent implements OnInit {
  title = 'My Classrooms';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  submitted = false;
  outputs: any = [];
  authCode: any;
  userId: any;
  sessUserId: any;
  // keyword wise array
  match_keywords: any;
  fileToUpload: any;
  filesize: any;
  maxsize: any;
  uploadMediaNames: any;
  urls: any;
  public Editor = ClassicEditor;
  width: any;
  all_classroom_data: any;
  responseComMessage: any;
  privateKey: any;
  classroom_offset: any;
  milisecond: any;
  actual_date: any;
  cur_date: any;
  minutes: any;
  hours: any;
  days: any;
  weeks: any;
  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private router: Router, private classroomService: ClassroomServiceService, private globalComponent: AppComponent, private cookieService: CookieService, private cd: ChangeDetectorRef, private spinner: NgxSpinnerService) {
      }
    // initialization
    ngOnInit() {
          this.spinner.hide();

          this.width = 0;
          this.classroom_offset = 0;
          this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
          this.authCode = this.cookieService.get('authCode');
          this.userId = this.cookieService.get('userId');
          this.sessUserId = this.globalComponent.replaceDollarByForward(this.userId);
          this.sessUserId = this.globalComponent.convertDecrypt(this.sessUserId, this.privateKey);

          this.get_all_classrooms(this.classroom_offset);
      }
             // check classroom member
             check_classroom_member(classroom_id) {
              this.spinner.show();
                  this.classroomService.url_checkClassRoomMemberApi(this.authCode, classroom_id).
                  subscribe(
                    data => {
                      this.Response = data;
                      if (this.Response.status === 200) {
                      setTimeout(() => {
                          /** spinner ends after 1 seconds */
                          this.spinner.hide();
                      }, 1000);
                        if (this.Response.data === '1') {
                          this.router.navigate(['/user_classroom_details/' + classroom_id ]);
                        } else {
                          alert('You are not member of this classroom. Please Try Again.');
                          return false;
                        }
                      } else {
                        this.responseMessage = this.Response.message;
                        alert('You are not member of this classroom. Please Try Again.');
                        /** spinner ends after 1 seconds */
                        setTimeout(() => {
                              this.spinner.hide();
                          }, 1000);
                          return false;
                      }
                    },
                    error => console.log( 'Error :: ' + error )
                    );
            }
      // get all classroom offset & limit wise
      get_all_classrooms(offset) {
              this.spinner.show();
              const offsett = 0;
              this.classroom_offset = (offset + 1);
                  this.classroomService.url_getSingleUserAllClassRoomsApi(this.authCode , offsett, this.classroom_offset).
                  subscribe(
                    data => {
                      this.Response = data;
                      if (this.Response.status === 200) {
                        if (this.classroom_offset === this.Response.data.length) {
                            $('#classroom_view_more').show();
                        } else {
                            $('#classroom_view_more').hide();
                        }
                        if (this.Response.data.length > 0) {
                          for (let i = 0; i < this.Response.data.length; i++) {
                            // tslint:disable-next-line:max-line-length
                             this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                            // tslint:disable-next-line:max-line-length
                             this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                          }
                        }
                        this.all_classroom_data = this.Response.data;
                        setTimeout(() => {
                            /** spinner ends after 1 seconds */
                            this.spinner.hide();
                        }, 1000);
                      } else {
                        this.responseMessage = this.Response.message;
                            /** spinner ends after 1 seconds */
                            setTimeout(() => {
                              this.spinner.hide();
                          }, 1000);
                      }
                    },
                    error => console.log( 'Error :: ' + error )
                    );
            }
      // Get blog time
      getClassroomTime(actual_date, short_date) {
          this.actual_date = new Date(actual_date);
          this.cur_date = new Date();
          const milisecond = Math.abs(this.actual_date - this.cur_date);
          const minutes = Math.floor((milisecond / 1000) / 60);
          const hours = Math.floor(minutes / 60);
          const rem_mins = Math.floor(minutes % 60);
          const days = Math.floor(hours / 24);
          const rem_hrs = Math.floor(hours % 24);
          if (minutes < 1) {
            return 'just now';
        } else if (minutes < 60) {
            return minutes + 'm';
        } else if (hours <= 24) {
            if (rem_mins !== 0) {
              return hours + 'h ' + rem_mins + 'm';
            }
            return hours + 'h';
        } else if (days < 7) {
            if (rem_hrs !== 0) {
              return days + 'd ' + rem_hrs + 'h';
            }
            return  days + 'd';
        } else if (days >= 7) {
            return short_date;
        } else {
            return false;
        }
      }
}

