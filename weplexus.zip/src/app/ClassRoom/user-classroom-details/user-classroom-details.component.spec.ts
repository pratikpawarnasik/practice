import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserClassroomDetailsComponent } from './user-classroom-details.component';

describe('UserClassroomDetailsComponent', () => {
  let component: UserClassroomDetailsComponent;
  let fixture: ComponentFixture<UserClassroomDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserClassroomDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserClassroomDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
