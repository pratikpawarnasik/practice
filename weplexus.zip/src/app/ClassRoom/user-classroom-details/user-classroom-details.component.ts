import { Component, OnInit , ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ClassroomServiceService } from '../services/user-classroom.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-user-classroom-details',
  templateUrl: './user-classroom-details.component.html',
  styleUrls: ['./user-classroom-details.component.scss']
})
export class UserClassroomDetailsComponent implements OnInit {
  title = 'ClassRoom Details';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  createClassRoomDiscussionForm: FormGroup;
  submitted = false;
  sub: any;
  authCode: any;
  userId: any;
  sessUserId: any;
  classroomId: any;
  // keyword wise array
  fileToUpload: any;
  filesize: any;
  maxsize: any;
  uploadMediaNames: any;
  urls: any;
  public Editor = ClassicEditor;
  width: any;
  files_cnt: any;
  all_classroom_data: any;
  all_discussion_data: any;
  // createCommentForm: any;
  com_submitted: any;
  responseComMessage: any;
  privateKey: any;
  discussion_offset: any;
  milisecond: any;
  actual_date: any;
  cur_date: any;
  minutes: any;
  hours: any;
  days: any;
  weeks: any;
  // update comment
  is_comment_id: any;
  is_comment_type: any;
  is_comment_index: any;
  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private classroomService: ClassroomServiceService, private globalComponent: AppComponent, private router: Router, private route: ActivatedRoute, private cookieService: CookieService, private cd: ChangeDetectorRef, private spinner: NgxSpinnerService) {

    // form initialize
      this.createClassRoomDiscussionForm = this.formBuilder.group({
              discussionTitle: ['', [Validators.required]],
              discussionDescription: ['', [Validators.required]],
           //   keywords: [''],
            gallery_files: [[]]
            });
      }
    // initialization
    ngOnInit() {
          $('.progress_bar_outer').hide();
          this.spinner.hide();

          this.width = 0;
          this.discussion_offset = 0;
          this.is_comment_id = '';
          this.is_comment_type = '';
          this.is_comment_index = '';
          this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
          this.authCode = this.cookieService.get('authCode');
          this.userId = this.cookieService.get('userId');
          this.sub = this.route.params.subscribe(params => {
            this.classroomId = params['classroomId']; // (+) converts string 'id' to a number
          });
          this.sessUserId = this.globalComponent.replaceDollarByForward(this.userId);
          this.sessUserId = this.globalComponent.convertDecrypt(this.sessUserId, this.privateKey);

         this.get_all_discussions(this.discussion_offset);
         this.get_single_classroom();
      }
      // Get Discussion time
      getTime(actual_date, short_date) {
          this.actual_date = new Date(actual_date);

         // const final_date = new Date(actual_date);
          // tslint:disable-next-line:max-line-length
         // alert(final_date.getDate() + '-' + final_date.getMonth() + '-' + final_date.getFullYear() + ' ' + final_date.getHours() + ':' + final_date.getMinutes() + ':' + final_date.getSeconds());

          this.cur_date = new Date();
          const milisecond = Math.abs(this.actual_date - this.cur_date);
          const minutes = Math.floor((milisecond / 1000) / 60);
          const hours = Math.floor(minutes / 60);
          const rem_mins = Math.floor(minutes % 60);
          const days = Math.floor(hours / 24);
          const rem_hrs = Math.floor(hours % 24);
          // const weeks = Math.floor(days / 7);
          // const rem_days = Math.floor(days % 7);
          // const months = Math.floor(days / 30);
          // const rem_m_all_days = Math.floor(days % 30);
          if (minutes < 1) {
            return 'just now';
        } else if (minutes < 60) {
            return minutes + 'm';
        } else if (hours <= 24) {
            if (rem_mins !== 0) {
              return hours + 'h ' + rem_mins + 'm';
            }
            return hours + 'h';
        } else if (days < 7) {
            if (rem_hrs !== 0) {
              return days + 'd ' + rem_hrs + 'h';
            }
            return  days + 'd';
        } else if (days >= 7) {
            return short_date;
        } else {
            return false;
        }
        // } else if (days >= 7) {
        //   if (rem_days !== 0) {
        //         return weeks + 'w ' + rem_days + 'd';
        //     }
        //     return weeks + 'w';
        // } else if (days >= 30) {
        //   if (rem_m_all_days !== 0) {
        //     return months + 'months ' + rem_m_all_days + 'd';
        //   }
        //   return months + 'months';
        // } else {
        //     return false;
        // }
      }
      // get single classroom
      get_single_classroom() {
              this.spinner.show();
                  this.classroomService.url_getSingleClassRoomsApi(this.authCode , this.classroomId).
                  subscribe(
                    data => {
                      this.Response = data;
                      if (this.Response.status === 200) {
                        // tslint:disable-next-line:max-line-length
                        this.Response.data.first_name = this.globalComponent.convertDecrypt(this.Response.data.first_name, this.Response.data.private_key);
                        // tslint:disable-next-line:max-line-length
                         this.Response.data.last_name = this.globalComponent.convertDecrypt(this.Response.data.last_name, this.Response.data.private_key);
                        this.all_classroom_data = this.Response.data;
                        setTimeout(() => {
                            /** spinner ends after 1 seconds */
                            this.spinner.hide();
                        }, 1000);
                      } else {
                        this.responseMessage = this.Response.message;
                            /** spinner ends after 1 seconds */
                            setTimeout(() => {
                              this.spinner.hide();
                          }, 1000);
                      }
                    },
                    error => console.log( 'Error :: ' + error )
                    );
            }
      // get all discussions offset & limit wise
      get_all_discussions(offset) {
        this.spinner.show();
        const offsett = 0;
        this.discussion_offset = (offset + 1);
            this.classroomService.url_getAllDiscussionsApi(this.authCode , offsett, this.discussion_offset).
            subscribe(
              data => {
                this.Response = data;
                if (this.Response.status === 200) {
                  if (this.discussion_offset === this.Response.data.length) {
                      $('#discussion_view_more').show();
                  } else {
                      $('#discussion_view_more').hide();
                  }
                  if (this.Response.data.length > 0) {
                    for (let i = 0; i < this.Response.data.length; i++) {
                      // tslint:disable-next-line:max-line-length
                       this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                      // tslint:disable-next-line:max-line-length
                       this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                    }
                  }
                  this.all_discussion_data = this.Response.data;
                  setTimeout(() => {
                      /** spinner ends after 1 seconds */
                      this.spinner.hide();
                  }, 1000);
                } else {
                  this.responseMessage = this.Response.message;
                      /** spinner ends after 1 seconds */
                      setTimeout(() => {
                        this.spinner.hide();
                    }, 1000);
                }
              },
              error => console.log( 'Error :: ' + error )
              );
      }
    // get get all discussion comments
    get_all_discussion_comments(discussion_id, main_index) {
            this.classroomService.url_getAllDiscussionCommentsApi(discussion_id).
            subscribe(
              data => {
                this.Response = data;
                if (this.Response.status === 200) {
                  if (this.Response.data.length > 0) {
                  for (let i = 0; i < this.Response.data.length; i++) {
                    // tslint:disable-next-line:max-line-length
                    this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                    // tslint:disable-next-line:max-line-length
                    this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                    // tslint:disable-next-line:max-line-length
                    if (this.Response.data[i].getAllDiscussionsSubComment.length > 0) {
                    for (let j = 0; j < this.Response.data[i].getAllDiscussionsSubComment.length; j++) {
                      // tslint:disable-next-line:max-line-length
                      this.Response.data[i].getAllDiscussionsSubComment[j].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].getAllDiscussionsSubComment[j].first_name, this.Response.data[i].getAllDiscussionsSubComment[j].private_key);
                      // tslint:disable-next-line:max-line-length
                      this.Response.data[i].getAllDiscussionsSubComment[j].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].getAllDiscussionsSubComment[j].last_name, this.Response.data[i].getAllDiscussionsSubComment[j].private_key);
                     }
                   }
                  }
                }
                  this.all_discussion_data[main_index].getAllDiscussionsComment = this.Response.data;
                  this.all_discussion_data[main_index].commentcnt = this.Response.data.length;
                } else {
                   this.responseMessage = this.Response.message;
                }
              },
              error => console.log( 'Error :: ' + error )
              );
        }
    // upload media gallery
    uploadImg(event) {
      this.uploadMediaNames = [];
      if (event.target.files && event.target.files.length > 0) {
        const filesAmount = event.target.files.length;
         for (let i = 0; i < filesAmount; i++) {
          $('.progress_bar_outer').show();
          this.width = 10;
          this.fileToUpload = [];
          this.fileToUpload = event.target.files[i];
          this.width = 30;
          const formData: FormData = new FormData();
          formData.append('media_data', this.fileToUpload);
          this.classroomService.url_uploadMediaDiscussionApi(formData).
                subscribe(
                  resultArray => {
                    this.width = 50;
                    this.Response = resultArray;
                    this.width = 70;
                    if (this.Response.status === 200) {
                      this.width = 100;
                      this.uploadMediaNames.push(this.Response.data);
                    } else {
                      alert(this.Response.message);
                    }
                  },
                  error => console.log('Error :: ' + error)
               );
           }
      }
    }
     // convenience getter for easy access to form fields
     get f() { return this.createClassRoomDiscussionForm.controls; }
      // convenience getter for easy access to form fields
      // Add Classroom discussions
      onSubmit() {
            this.submitted = true;
            this.responseMessage = '';
            // stop here if form is invalid
            if (this.createClassRoomDiscussionForm.invalid) {
                    return false;
                }
              // tslint:disable-next-line:max-line-length
              const discussionTitle = this.globalComponent.convertEncrypt(this.createClassRoomDiscussionForm.controls.discussionTitle.value);
              // tslint:disable-next-line:max-line-length
              const discussionDescription = this.globalComponent.convertEncrypt(this.createClassRoomDiscussionForm.controls.discussionDescription.value);

              const formData: FormData = new FormData();
              formData.append('user_id', this.userId);
              formData.append('classroom_id', this.classroomId);
              formData.append('titleDiscussion', discussionTitle);
              formData.append('discussionDescription', discussionDescription);
              formData.append('authCode', this.authCode);
              formData.append('uploadMedia', JSON.stringify(this.uploadMediaNames));
              this.classroomService.url_createDiscussionApi(formData).
                    subscribe(
                      resultArray => {
                        this.Response = resultArray;
                        if (this.Response.status === 200) {
                          this.uploadMediaNames = [];
                          alert(this.Response.message);
                          this.responseMessage = '';
                          this.submitted = false;
                          this.width = 0;
                          $('.progress_bar_outer').hide();
                          this.createClassRoomDiscussionForm.reset();
                         // this.createClassRoomDiscussionForm.patchValue({'gallery_files': []});
                          this.get_all_discussions(this.discussion_offset);
                        } else {
                          this.responseMessage = this.Response.message;
                        }
                      },
                      error => console.log('Error :: ' + error)
                   );
          }
     // Add Discussion Comments
      onSubmitComment(parent_comment_id, discussion_id, main_index, index) {
        this.com_submitted = true;
        this.responseComMessage = '';
        let comment_text = '';
            if (parent_comment_id  !== '' ) {
                comment_text = this.globalComponent.convertEncrypt($('#comment_id_' + index).val());
                if (comment_text === '') {
                    return false;
                }
             } else {
              comment_text = this.globalComponent.convertEncrypt($('#parent_comment_id_' + main_index).val());
              if (comment_text === '') {
                    return false;
                }
            }
          const formData: FormData = new FormData();
          formData.append('user_id', this.userId);
          formData.append('discussion_id', discussion_id);
          formData.append('comment_text', comment_text);
          formData.append('authCode', this.authCode);
          formData.append('parent_comment_id', parent_comment_id);
          this.classroomService.url_discussionCommentApi(formData).
                subscribe(
                  resultArray => {
                    this.Response = resultArray;
                    if (this.Response.status === 200) {
                      alert(this.Response.message);
                      this.responseComMessage = '';
                      this.com_submitted = false;
                      if (parent_comment_id  !== '' ) {
                        $('#comment_id_' + index).val('');
                      } else {
                        $('#parent_comment_id_' + main_index).val('');
                      }
                      this.get_all_discussion_comments(discussion_id, main_index);
                    } else {
                      this.responseComMessage = this.Response.message;
                    }
                  },
                  error => console.log('Error :: ' + error)
            );
      }
      // Update Discussion Comments
      onSetCommentValue(parent_comment_id, dis_comment_id, value, index) {
        this.is_comment_id =  '';
        this.is_comment_type = '';
        this.is_comment_index = '';
          if (parent_comment_id  !== '' ) {
            $('#comment_id_' + index).val(value);
            this.is_comment_type = '2';
        } else {
            $('#parent_comment_id_' + index).val(value);
            this.is_comment_type = '1';
        }
        this.is_comment_id = dis_comment_id;
        this.is_comment_index = index;
      }
      // Update Discussion Comments
      onUpdateComment(discussion_id, main_index, index) {
        this.responseComMessage = '';
        let comment_text = '';
            if (index  !== '' ) {
                comment_text = this.globalComponent.convertEncrypt($('#comment_id_' + index).val());
                if (comment_text === '') {
                    return false;
                }
             } else {
              comment_text = this.globalComponent.convertEncrypt($('#parent_comment_id_' + main_index).val());
              if (comment_text === '') {
                    return false;
                }
            }
          this.is_comment_id = this.globalComponent.convertEncrypt(this.is_comment_id);
          const formData: FormData = new FormData();
          formData.append('user_id', this.userId);
          formData.append('comment_id', this.is_comment_id);
          formData.append('comment_text', comment_text);
          formData.append('authCode', this.authCode);
          this.classroomService.url_updateDiscussionCommentApi(formData).
                subscribe(
                  resultArray => {
                    this.Response = resultArray;
                    if (this.Response.status === 200) {
                      alert(this.Response.message);
                      this.responseComMessage = '';
                      this.is_comment_id =  '';
                      this.is_comment_type = '';
                      this.is_comment_index = '';
                      if (index  !== '' ) {
                        $('#comment_id_' + index).val('');
                      } else {
                        $('#parent_comment_id_' + main_index).val('');
                      }
                       this.get_all_discussion_comments(discussion_id, main_index);
                    } else {
                      this.responseComMessage = this.Response.message;
                    }
                  },
                  error => console.log('Error :: ' + error)
            );
      }
       // Add Discussion Likes
      addDiscussionLike(discussion_id, index) {
              const formData: FormData = new FormData();
              formData.append('user_id', this.userId);
              formData.append('discussion_id', discussion_id);
              formData.append('authCode', this.authCode);
              this.classroomService.url_discussionLikeApi(formData).
                  subscribe(
                      resultArray => {
                        this.Response = resultArray;
                        if (this.Response.status === 200 || this.Response.status === 201) {
                          this.responseComMessage = '';
                          if (this.Response.status === 200) {
                            this.all_discussion_data[index].discussionUserLike = 1;
                          }
                          if (this.Response.status === 201) {
                            this.all_discussion_data[index].discussionUserLike = 0;
                          }
                          this.all_discussion_data[index].likescnt = this.Response.data;
                        } else {
                          this.responseComMessage = this.Response.message;
                        }
                      },
                      error => console.log('Error :: ' + error)
                );
          }
}

