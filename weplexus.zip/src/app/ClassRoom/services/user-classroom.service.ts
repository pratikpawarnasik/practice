import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { Http, Response } from '@angular/http';
import { CookieService } from 'ngx-cookie-service';
import { GlobalsService } from '../../globals.service';

@Injectable({
  providedIn: 'root'
})
export class ClassroomServiceService {
  constructor(private http: Http, private globals: GlobalsService, private cookieService: CookieService) { }
  userId = this.cookieService.get('userId');
  userEmail = this.cookieService.get('userEmail');
  userFirstName = this.cookieService.get('userFirstName');
  userLastName = this.cookieService.get('userLastName');
  userType = this.cookieService.get('userType');
  authCode = this.cookieService.get('authCode');
  privateKey = this.cookieService.get('privateKey');

  // error handler
  private handleError(error: Response) {
      return 'error';
    }
  // create ClassRoom
  url_createClassRoomApi(data) {
    return this.http
    .post(this.globals.addClassRoomAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
      // url_check Invite ClassRoom Member Api
    url_checkInviteClassRoomApi(auth_code, unique_code) {
        return this.http
        .get(this.globals.checkInviteClassRoomMemberAPIUrl + '/' + auth_code + '/' + unique_code).pipe(
        map((response: Response) => {
          return response.json();
        }),
        catchError(this.handleError));
    }
    // invite verify ClassRoom
    url_verifyInviteClassRoomApi(data) {
      return this.http
      .post(this.globals.verifyInviteClassRoomMemberAPIUrl, data).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
    }
  // create ClassRoom
  url_inviteUserForClassRoomApi(data) {
    return this.http
    .post(this.globals.inviteUserForClassRoomAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
    // Get all email keyword wise
    url_getEmailDetailsApi(email) {
      return this.http
      .get(this.globals.getSearchEmailsAPIUrl + '/' + email).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
    }
  // create join Class Room
  url_joinClassRoomApi(data) {
    return this.http
    .post(this.globals.joinClassRoomAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
    // Get allClassRooms offset & limit wise
    url_getAllClassRoomsApi(auth_code, offset, limit) {
      return this.http
      .get(this.globals.getAllClassRoomAPIUrl + '/' + auth_code + '/' + offset + '/' + limit).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
  }
      // Get allClassRooms offset & limit wise
      url_getSingleUserAllClassRoomsApi(auth_code, offset, limit) {
        return this.http
        .get(this.globals.getSingleUserClassRoomAPIUrl + '/' + auth_code + '/' + offset + '/' + limit).pipe(
        map((response: Response) => {
          return response.json();
        }),
        catchError(this.handleError));
    }
  // Get sigle ClassRoom
  url_getSingleClassRoomsApi(auth_code, classroom_id) {
    return this.http
    .get(this.globals.getSingleClassRoomAPIUrl + '/' + auth_code + '/' + classroom_id).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
}
  // Get all join requests
  url_getJoinRequestApi(auth_code) {
    return this.http
    .get(this.globals.getClassRoomJoinRequestAPIUrl + '/' + auth_code).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
  // update join requests
  url_updateJoinRequestApi(member_id, auth_code) {
    return this.http
    .get(this.globals.updateClassRoomJoinRequestAPIUrl + '/' + member_id + '/' + auth_code).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
  // Get all Keyword serach box wise
  url_getKeywordDetailsApi(keyword) {
      return this.http
      .get(this.globals.getClassRoomKeywordsAPIUrl + '/' + keyword).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
    }

// discussion services

// create discussion
url_createDiscussionApi(data) {
  return this.http
  .post(this.globals.createDiscussionAPIUrl, data).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
}
// Classroom images/videos upload
url_uploadMediaDiscussionApi(data) {
  return this.http
  .post(this.globals.uploadMediaDiscussionAPIUrl, data).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
}
// Get all Classroom Keyword keyword wise
url_getKeywordDetailsApi1(keyword) {
    return this.http
    .get(this.globals.getKeywordsAPIUrl + '/' + keyword).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
// Get all Classroom Keyword keyword wise
url_checkClassRoomMemberApi(authCode, classroom_id) {
  return this.http
  .get(this.globals.checkClassRoomMemberAPIUrl + '/' + authCode + '/' + classroom_id).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
}
// Get all Discussions offset & limit wise
  url_getAllDiscussionsApi(auth_code, offset, limit) {
      return this.http
      .get(this.globals.getAllDiscussionAPIUrl + '/' + auth_code + '/' + offset + '/' + limit).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
  }
  // Add Discussion Comment
  url_discussionCommentApi(data) {
    return this.http
    .post(this.globals.addDiscussionCommentAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
 // Update Discussion Comment
  url_updateDiscussionCommentApi(data) {
        return this.http
        .post(this.globals.updateDiscussionCommentAPIUrl, data).pipe(
        map((response: Response) => {
          return response.json();
        }),
        catchError(this.handleError));
      }
   // Get all Discussion Comments
   url_getAllDiscussionCommentsApi(discussion_id) {
    return this.http
    .get(this.globals.getDiscussionCommentAPIUrl + '/' + discussion_id).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
  // Discussion add like
  url_discussionLikeApi(data) {
    return this.http
    .post(this.globals.addDiscussionLikeAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
}
