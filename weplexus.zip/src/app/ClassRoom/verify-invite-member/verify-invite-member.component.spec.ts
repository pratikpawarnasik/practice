import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyInviteMemberComponent } from './verify-invite-member.component';

describe('VerifyInviteMemberComponent', () => {
  let component: VerifyInviteMemberComponent;
  let fixture: ComponentFixture<VerifyInviteMemberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerifyInviteMemberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyInviteMemberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
