import { Component, OnInit , ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClassroomServiceService } from '../services/user-classroom.service';
import { UserServiceService } from '../../user-service.service';
import { Router, Route , ActivatedRoute} from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-verify-invite-member',
  templateUrl: './verify-invite-member.component.html',
  styleUrls: ['./verify-invite-member.component.scss']
})
export class VerifyInviteMemberComponent implements OnInit {
  title = 'Verify Invite Member For Classroom';
  createClassroomInvitationForm: FormGroup;
  submitted = false;
  Response: any;
  responseMessage: any;
  status: any;
  authCode: any;
  userId: any;
  sub: any;
  classroomId: any;
  inviteUserId: any;
  urls: any;
  classroom_data: any;

  responseComMessage: any;
  privateKey: any;
  uniqueCode: any;
  emailId: any;
  // tslint:disable-next-line:max-line-length
  constructor(private authService: UserServiceService, private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, private classroomService: ClassroomServiceService, private globalComponent: AppComponent, private cookieService: CookieService, private cd: ChangeDetectorRef, private spinner: NgxSpinnerService) {
      // form initialize
      this.createClassroomInvitationForm = this.formBuilder.group({
        unique_key: ['', [Validators.required]],
      });
  }
    // initialization
    ngOnInit() {
          this.spinner.hide();
          this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
          this.authCode = this.cookieService.get('authCode');
          this.userId = this.cookieService.get('userId');
          // login parameters
          const log_type =  this.globalComponent.replaceForwardByDollar(this.globalComponent.convertEncrypt('verify-invitation'));

          this.sub = this.route.params.subscribe(params => {
            this.uniqueCode = params['uniqueCode'];
          });
          // this.verifyInviteUserForClassroom();
          this.checkInviteUserForClassroom();
          if (this.authService.isLoggedUser()) {
            return true;
        } else {
            // navigate to login page
            this.router.navigate(['/login/' + log_type + '/' + this.uniqueCode]);
            // you can save redirect url so after authing we can move them back to the page they requested
            return false;
        }
      }
  // get all classroom offset & limit wise
  checkInviteUserForClassroom() {
        this.spinner.show();
        this.classroomService.url_checkInviteClassRoomApi(this.authCode , this.uniqueCode).
        subscribe(
          data => {
            this.Response = data;
            if (this.Response.status === 200) {
              alert(this.Response.message);
             // this.classroom_data = this.Response.data;
             this.emailId = this.Response.data.invite_email;
             this.classroomId = this.Response.data.classroom_id;
             this.inviteUserId =  this.Response.data.invite_user_id;
              console.log(this.Response.data);
              setTimeout(() => {
                  /** spinner ends after 1 seconds */
                  this.spinner.hide();
              }, 1000);
            } else {
              this.responseMessage = this.Response.message;
                  /** spinner ends after 1 seconds */
                  setTimeout(() => {
                    this.spinner.hide();
                }, 1000);
            }
          },
          error => console.log( 'Error :: ' + error )
          );
  }
    // convenience getter for easy access to form fields
    get f() { return this.createClassroomInvitationForm.controls; }
   // Verify invite users for Classroom
   verifyInviteUserForClassroom() {
            this.submitted = true;
            this.responseMessage = '';
            // stop here if form is invalid
            if (this.createClassroomInvitationForm.invalid) {
                    return false;
                }
            const unique_key = this.globalComponent.convertEncrypt(this.createClassroomInvitationForm.controls.unique_key.value);
            const formData: FormData = new FormData();
            formData.append('user_id', this.userId);
            formData.append('invite_user_id', this.inviteUserId);
            formData.append('classroom_id', this.classroomId);
            formData.append('authCode', this.authCode);
            formData.append('uniqueCode', this.uniqueCode);
            formData.append('email', this.emailId);
            formData.append('unique_key', unique_key);
              this.classroomService.url_verifyInviteClassRoomApi(formData).
                    subscribe(
                      resultArray => {
                        this.Response = resultArray;
                        if (this.Response.status === 200) {
                          alert(this.Response.message);
                          this.responseMessage = '';
                          this.submitted = false;
                          this.createClassroomInvitationForm.reset();
                        } else {
                          this.responseMessage = this.Response.message;
                        }
                      },
                      error => console.log('Error :: ' + error)
                );
      }
}
