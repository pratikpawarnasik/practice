import { Component, OnInit , ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClassroomServiceService } from '../services/user-classroom.service';
import { Router, Route , ActivatedRoute} from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-invite-private-classroom-user',
  templateUrl: './invite-private-classroom-user.component.html',
  styleUrls: ['./invite-private-classroom-user.component.scss']
})
export class InvitePrivateClassroomUserComponent implements OnInit {
  title = 'Invite Member For Classroom';
  Response: any;
  responseMessage: any;
  status: any;
  inviteClassroomForm: FormGroup;
  submitted = false;
  outputs: any = [];
  authCode: any;
  userId: any;
  sub: any;
  classroomId: any;
  // email wise array
  match_emails: any;
  urls: any;
  public Editor = ClassicEditor;
  width: any;
  classroom_data: any;

  responseComMessage: any;
  privateKey: any;
  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, private classroomService: ClassroomServiceService, private globalComponent: AppComponent, private cookieService: CookieService, private cd: ChangeDetectorRef, private spinner: NgxSpinnerService) {
  // form initialize
  this.inviteClassroomForm = this.formBuilder.group({
              emails: [''],
              classroomTitle: ['']
            });
      }
    // initialization
    ngOnInit() {
          this.spinner.hide();

          this.width = 0;
          this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
          this.authCode = this.cookieService.get('authCode');
          this.userId = this.cookieService.get('userId');

          this.sub = this.route.params.subscribe(params => {
            this.classroomId = params['classroomId']; // (+) converts string 'id' to a number
          });
         this.get_single_classrooms();
      }
      // get all classroom offset & limit wise
      get_single_classrooms() {
              this.spinner.show();
                  this.classroomService.url_getSingleClassRoomsApi(this.authCode , this.classroomId).
                  subscribe(
                    data => {
                      this.Response = data;
                      if (this.Response.status === 200) {
                        if (this.Response.data.length > 0) {
                          for (let i = 0; i < this.Response.data.length; i++) {
                            // tslint:disable-next-line:max-line-length
                             this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                            // tslint:disable-next-line:max-line-length
                             this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                          }
                        }
                        this.classroom_data = this.Response.data;
                        this.inviteClassroomForm.patchValue( {'classroomTitle': this.classroom_data.title});
                        setTimeout(() => {
                            /** spinner ends after 1 seconds */
                            this.spinner.hide();
                        }, 1000);
                      } else {
                        this.responseMessage = this.Response.message;
                            /** spinner ends after 1 seconds */
                            setTimeout(() => {
                              this.spinner.hide();
                          }, 1000);
                      }
                    },
                    error => console.log( 'Error :: ' + error )
                    );
            }
   // tslint:disable-next-line:member-ordering
   public validateEmail(email) {
        // tslint:disable-next-line:max-line-length
        const test_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        const isEmailValid = test_email.test(email);
        return isEmailValid;
      }
    // add emails in array
    addEmailInput(event) {
        if (event.which === 13) {
         const email_value = this.inviteClassroomForm.controls.emails.value;
         const isEmailValid = this.validateEmail(email_value);
         if (isEmailValid) {
          const index = this.outputs.indexOf(email_value);
            if (index === -1) {
              this.outputs.push(email_value);
            } else {
              // same email override
              this.outputs[index] = email_value;
            }
          this.inviteClassroomForm.patchValue( {'emails': null});
         } else {
            alert('Email id is not valid.');
         }
        }
      }
    // add email for select value from search dropdown
    addEmailDropdown(value) {
          if (value !== '') {
            const index = this.outputs.indexOf(value);
              if (index === -1) {
                this.outputs.push(value);
              } else {
                // same email override
                this.outputs[index] = value;
              }
              this.inviteClassroomForm.patchValue({'emails': null});
              this.match_emails = [];
          }
        }
    // remove email from email array
    removeEmail(index) {
          if (index !== '') {
            this.outputs.splice(index, 1);
          }
        }
    // get all emails by email wise
    get_all_emails(email) {
        if (email !== '') {
          email = this.globalComponent.replaceForwardByDollar(this.globalComponent.convertEncrypt(email));
          console.log(email);
          this.classroomService.url_getEmailDetailsApi(email).
          subscribe(
            data => {
              this.Response = data;
              if (this.Response.status === 200) {
                if (this.Response.data.length > 0) {
                  for (let i = 0; i < this.Response.data.length; i++) {
                    // tslint:disable-next-line:max-line-length
                     this.Response.data[i].email = this.globalComponent.convertDecrypt(this.Response.data[i].email);
                  }
                }
               this.match_emails = this.Response.data;
              } else {
                this.responseMessage = this.Response.message;
              }
            },
            error => console.log( 'Error :: ' + error )
            );
        } else {
          this.match_emails = [];
        }
     }
  // convenience getter for easy access to form fields
  get f() { return this.inviteClassroomForm.controls; }
   // Invite users for Classroom
   onSubmit() {
     if (this.outputs.length > 0) {
            this.responseMessage = '';
              const formData: FormData = new FormData();
              formData.append('user_id', this.userId);
              formData.append('classroom_id', this.classroomId);
              formData.append('emails',  this.outputs);
              formData.append('authCode', this.authCode);
              this.classroomService.url_inviteUserForClassRoomApi(formData).
                    subscribe(
                      resultArray => {
                        this.Response = resultArray;
                        if (this.Response.status === 200) {
                          this.outputs = [];
                          alert(this.Response.message);
                          this.responseMessage = '';
                          this.submitted = false;
                        } else {
                          this.responseMessage = this.Response.message;
                        }
                      },
                      error => console.log('Error :: ' + error)
                );
             } else {
                alert('Please add emails.');
             }
      }
}

