import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvitePrivateClassroomUserComponent } from './invite-private-classroom-user.component';

describe('InvitePrivateClassroomUserComponent', () => {
  let component: InvitePrivateClassroomUserComponent;
  let fixture: ComponentFixture<InvitePrivateClassroomUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvitePrivateClassroomUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvitePrivateClassroomUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
