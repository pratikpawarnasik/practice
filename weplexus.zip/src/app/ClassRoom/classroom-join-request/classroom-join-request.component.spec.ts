import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassroomJoinRequestComponent } from './classroom-join-request.component';

describe('ClassroomJoinRequestComponent', () => {
  let component: ClassroomJoinRequestComponent;
  let fixture: ComponentFixture<ClassroomJoinRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClassroomJoinRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClassroomJoinRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
