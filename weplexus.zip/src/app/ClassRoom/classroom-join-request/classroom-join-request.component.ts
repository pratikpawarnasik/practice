import { Component, OnInit , ChangeDetectorRef } from '@angular/core';
import { ClassroomServiceService } from '../services/user-classroom.service';

import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-classroom-join-request',
  templateUrl: './classroom-join-request.component.html',
  styleUrls: ['./classroom-join-request.component.scss']
})
export class ClassroomJoinRequestComponent implements OnInit {
  title = 'Classroom Join Requests';
  Response: any;
  responseMessage: any;
  authCode: any;
  userId: any;
  sessUserId: any;
  privateKey: any;
  all_classroom_join_req_data: any;
  // tslint:disable-next-line:max-line-length
  constructor(private classroomService: ClassroomServiceService, private globalComponent: AppComponent, private cookieService: CookieService) {
      }
    // initialization
    ngOnInit() {
          this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
          this.authCode = this.cookieService.get('authCode');
          this.userId = this.cookieService.get('userId');
          this.sessUserId = this.globalComponent.replaceDollarByForward(this.userId);
          this.sessUserId = this.globalComponent.convertDecrypt(this.sessUserId, this.privateKey);

          this.get_all_join_classroom_requests();
      }
    // update join classroom request
    update_join_classroom_req(member_id, index) {
      this.classroomService.url_updateJoinRequestApi(member_id, this.authCode).
            subscribe(
              resultArray => {
                this.Response = resultArray;
                if (this.Response.status === 200) {
                  this.all_classroom_join_req_data[index].is_join = this.Response.data;
                  alert(this.Response.message);
                } else {
                  this.responseMessage = this.Response.message;
                }
              },
              error => console.log('Error :: ' + error)
            );
     }
    // get all join classroom requests
    get_all_join_classroom_requests() {
      this.classroomService.url_getJoinRequestApi(this.authCode).
            subscribe(
              resultArray => {
                this.Response = resultArray;
                if (this.Response.status === 200) {
                  if (this.Response.data.length > 0) {
                    for (let i = 0; i < this.Response.data.length; i++) {
                      // tslint:disable-next-line:max-line-length
                       this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                      // tslint:disable-next-line:max-line-length
                       this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                    }
                  }
                  this.all_classroom_join_req_data = this.Response.data;
                } else {
                  this.responseMessage = this.Response.message;
                  this.all_classroom_join_req_data = [];
                }
              },
              error => console.log('Error :: ' + error)
            );
     }
}

