import { Component, OnInit , ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClassroomServiceService } from '../services/user-classroom.service';
import { Router, Route } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-classroom',
  templateUrl: './classroom.component.html',
  styleUrls: ['./classroom.component.scss']
})
export class ClassroomComponent implements OnInit {
  title = 'Create Classroom';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  createClassroomForm: FormGroup;
  submitted = false;
  outputs: any = [];
  authCode: any;
  userId: any;
  sessUserId: any;
  // keyword wise array
  match_keywords: any;
  fileToUpload: any;
  filesize: any;
  maxsize: any;
  uploadMediaNames: any;
  urls: any;
  public Editor = ClassicEditor;
  width: any;
  all_classroom_data: any;
  responseComMessage: any;
  privateKey: any;
  classroom_offset: any;
  milisecond: any;
  actual_date: any;
  cur_date: any;
  minutes: any;
  hours: any;
  days: any;
  weeks: any;
  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private router: Router, private classroomService: ClassroomServiceService, private globalComponent: AppComponent, private cookieService: CookieService, private cd: ChangeDetectorRef, private spinner: NgxSpinnerService) {

    // form initialize
      this.createClassroomForm = this.formBuilder.group({
              classroomTitle: ['', [Validators.required]],
              classroomDescription: ['', [Validators.required]],
              classroomType: ['', [Validators.required]],
              keywords: ['']
            });
      }
    // initialization
    ngOnInit() {
          this.spinner.hide();

          this.width = 0;
          this.classroom_offset = 0;
          this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
          this.authCode = this.cookieService.get('authCode');
          this.userId = this.cookieService.get('userId');
          this.sessUserId = this.globalComponent.replaceDollarByForward(this.userId);
          this.sessUserId = this.globalComponent.convertDecrypt(this.sessUserId, this.privateKey);

          this.get_all_classrooms(this.classroom_offset);
      }
       // check classroom member
       check_classroom_member(classroom_id) {
        this.spinner.show();
            this.classroomService.url_checkClassRoomMemberApi(this.authCode, classroom_id).
            subscribe(
              data => {
                this.Response = data;
                if (this.Response.status === 200) {
                setTimeout(() => {
                    /** spinner ends after 1 seconds */
                    this.spinner.hide();
                }, 1000);
                  if (this.Response.data === '1') {
                    this.router.navigate(['/user_classroom_details/' + classroom_id ]);
                  } else {
                    alert('You are not member of this classroom. Please Try Again.');
                    return false;
                  }
                } else {
                  this.responseMessage = this.Response.message;
                  alert('You are not member of this classroom. Please Try Again.');
                  /** spinner ends after 1 seconds */
                  setTimeout(() => {
                        this.spinner.hide();
                    }, 1000);
                    return false;
                }
              },
              error => console.log( 'Error :: ' + error )
              );
      }
      // get all classroom offset & limit wise
      get_all_classrooms(offset) {
              this.spinner.show();
              const offsett = 0;
              this.classroom_offset = (offset + 1);
                  this.classroomService.url_getAllClassRoomsApi(this.authCode , offsett, this.classroom_offset).
                  subscribe(
                    data => {
                      this.Response = data;
                      if (this.Response.status === 200) {
                        if (this.classroom_offset === this.Response.data.length) {
                            $('#classroom_view_more').show();
                        } else {
                            $('#classroom_view_more').hide();
                        }
                        if (this.Response.data.length > 0) {
                          for (let i = 0; i < this.Response.data.length; i++) {
                            // tslint:disable-next-line:max-line-length
                             this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                            // tslint:disable-next-line:max-line-length
                             this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                          }
                        }
                        this.all_classroom_data = this.Response.data;
                        setTimeout(() => {
                            /** spinner ends after 1 seconds */
                            this.spinner.hide();
                        }, 1000);
                      } else {
                        this.responseMessage = this.Response.message;
                            /** spinner ends after 1 seconds */
                            setTimeout(() => {
                              this.spinner.hide();
                          }, 1000);
                      }
                    },
                    error => console.log( 'Error :: ' + error )
                    );
            }
      // Get blog time
      getClassroomTime(actual_date, short_date) {
          this.actual_date = new Date(actual_date);
          this.cur_date = new Date();
          const milisecond = Math.abs(this.actual_date - this.cur_date);
          const minutes = Math.floor((milisecond / 1000) / 60);
          const hours = Math.floor(minutes / 60);
          const rem_mins = Math.floor(minutes % 60);
          const days = Math.floor(hours / 24);
          const rem_hrs = Math.floor(hours % 24);
          // const weeks = Math.floor(days / 7);
          // const rem_days = Math.floor(days % 7);
          // const months = Math.floor(days / 30);
          // const rem_m_all_days = Math.floor(days % 30);
          if (minutes < 1) {
            return 'just now';
        } else if (minutes < 60) {
            return minutes + 'm';
        } else if (hours <= 24) {
            if (rem_mins !== 0) {
              return hours + 'h ' + rem_mins + 'm';
            }
            return hours + 'h';
        } else if (days < 7) {
            if (rem_hrs !== 0) {
              return days + 'd ' + rem_hrs + 'h';
            }
            return  days + 'd';
        } else if (days >= 7) {
            return short_date;
        } else {
            return false;
        }
        // } else if (days >= 7) {
        //   if (rem_days !== 0) {
        //         return weeks + 'w ' + rem_days + 'd';
        //     }
        //     return weeks + 'w';
        // } else if (days >= 30) {
        //   if (rem_m_all_days !== 0) {
        //     return months + 'months ' + rem_m_all_days + 'd';
        //   }
        //   return months + 'months';
        // } else {
        //     return false;
        // }
      }
    // add keywords in array
    addKeywordInput(event) {
        if (event.which === 13) {
          const keyword_value = this.createClassroomForm.controls.keywords.value;
          const index = this.outputs.indexOf(keyword_value);
            if (index === -1) {
              this.outputs.push(keyword_value);
            } else {
              // same keyword override
              this.outputs[index] = keyword_value;
            }
          this.createClassroomForm.patchValue( {'keywords': null});
        }
      }
    // add keyword for select value from search dropdown
    addKeywordDropdown(value) {
          if (value !== '') {
            const index = this.outputs.indexOf(value);
              if (index === -1) {
                this.outputs.push(value);
              } else {
                // same keyword override
                this.outputs[index] = value;
              }
              this.createClassroomForm.patchValue({'keywords': null});
              this.match_keywords = [];
          }
        }
    // remove keyword from keyword array
    removeKeyword(index)  {
          if (index !== '') {
            this.outputs.splice(index, 1);
          }
        }
    // get all keywords by keyword wise
    get_all_keywords(keyWord) {
        if (keyWord !== '') {
          this.classroomService.url_getKeywordDetailsApi(keyWord).
          subscribe(
            data => {
              this.Response = data;
              if (this.Response.status === 200) {
               this.match_keywords = this.Response.data;
              } else {
                this.responseMessage = this.Response.message;
              }
            },
            error => console.log( 'Error :: ' + error )
            );
        } else {
          this.match_keywords = [];
        }
     }
   // user join the classroom
   join_classroom(classroom_id, index) {
     const formData: FormData = new FormData();
     formData.append('user_id', this.userId);
     formData.append('classroom_id', classroom_id);
     formData.append('authCode', this.authCode);
     this.classroomService.url_joinClassRoomApi(formData).
           subscribe(
             resultArray => {
               this.Response = resultArray;
               if (this.Response.status === 200) {
                 alert(this.Response.message);
                 this.all_classroom_data[index].user_join_request = this.Response.data;
               } else {
                 this.responseMessage = this.Response.message;
               }
             },
             error => console.log('Error :: ' + error)
           );
    }
  // convenience getter for easy access to form fields
  get f() { return this.createClassroomForm.controls; }
   // Add Classroom
   onSubmit() {
            this.submitted = true;
            this.responseMessage = '';
            // stop here if form is invalid
            if (this.createClassroomForm.invalid) {
                    return false;
                }
              const classroomTitle = this.globalComponent.convertEncrypt(this.createClassroomForm.controls.classroomTitle.value);
              // tslint:disable-next-line:max-line-length
              const classroomDescription = this.globalComponent.convertEncrypt(this.createClassroomForm.controls.classroomDescription.value);
              const classroomType = this.globalComponent.convertEncrypt(this.createClassroomForm.controls.classroomType.value);
              // const validity_days = this.globalComponent.convertEncrypt(this.createClassroomForm.controls.validity_days.value);
              // const reference = this.globalComponent.convertEncrypt(this.createClassroomForm.controls.reference.value);

              const formData: FormData = new FormData();
              formData.append('user_id', this.userId);
              formData.append('titleClassroom', classroomTitle);
              formData.append('classroomDescription', classroomDescription);
              formData.append('classroomType', classroomType);
              // formData.append('validity_days', validity_days);
              formData.append('keywords',  this.outputs);
              // formData.append('reference', reference);
              formData.append('authCode', this.authCode);
             // formData.append('uploadMedia', JSON.stringify(this.uploadMediaNames));
              this.classroomService.url_createClassRoomApi(formData).
                    subscribe(
                      resultArray => {
                        this.Response = resultArray;
                        if (this.Response.status === 200) {
                          this.outputs = [];
                          alert(this.Response.message);
                          this.responseMessage = '';
                          this.submitted = false;
                          $('.progress_bar_outer').hide();
                          this.createClassroomForm.reset();
                          this.get_all_classrooms(this.classroom_offset);
                        } else {
                          this.responseMessage = this.Response.message;
                        }
                      },
                      error => console.log('Error :: ' + error)
                );
          }
}
