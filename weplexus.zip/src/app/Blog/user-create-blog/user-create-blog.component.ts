import { Component, OnInit , ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserBlogService } from '../services/user-blog.service';
import { CookieService } from 'ngx-cookie-service';
import { NgxSpinnerService } from 'ngx-spinner';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';

@Component({
  selector: 'app-user-create-blog',
  templateUrl: './user-create-blog.component.html',
  styleUrls: ['./user-create-blog.component.scss']
})
export class UserCreateBlogComponent implements OnInit {
  title = 'Create Blog';
  Response: any;
  splitted: any;
  responseMessage: any;
  status: any;
  createBlogForm: FormGroup;
  submitted = false;
  outputs: any = [];
  authCode: any;
  userId: any;
  // keyword wise array
  match_keywords: any;
  fileToUpload: any;
  filesize: any;
  maxsize: any;
  uploadMediaNames: any;
  urls: any;
  public Editor = ClassicEditor;
  width: any;
  files_cnt: any;
  all_blog_data: any;
  // createCommentForm: any;
  com_submitted: any;
  responseComMessage: any;
  privateKey: any;
  blog_offset: any;
  milisecond: any;
  actual_date: any;
  cur_date: any;
  minutes: any;
  hours: any;
  days: any;
  weeks: any;
  // update comment
  is_comment_id: any;
  is_comment_type: any;
  is_comment_index: any;
  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, private blogService: UserBlogService, private globalComponent: AppComponent, private cookieService: CookieService, private cd: ChangeDetectorRef, private spinner: NgxSpinnerService) {

    // form initialize
      this.createBlogForm = this.formBuilder.group({
              blogTitle: ['', [Validators.required]],
              blogDescription: ['', [Validators.required]],
              reference: ['', [Validators.required]],
              validity_days: ['', [Validators.required]],
              blogType: ['', [Validators.required]],
              keywords: [''],
              gallery_files: [[]]
            });
      }
    // initialization
    ngOnInit() {
          $('.progress_bar_outer').hide();
          this.spinner.hide();

          this.width = 0;
          this.blog_offset = 0;
          this.is_comment_id = '';
          this.is_comment_type = '';
          this.is_comment_index = '';
          this.privateKey = this.globalComponent.replaceDollarByForward(this.cookieService.get('privateKey'));
          this.authCode = this.cookieService.get('authCode');
          this.userId = this.cookieService.get('userId');

          this.get_all_blogs(this.blog_offset);
      }
      // Get blog time
      getBlogTime(actual_date, short_date) {
          this.actual_date = new Date(actual_date);
          this.cur_date = new Date();
          const milisecond = Math.abs(this.actual_date - this.cur_date);
          const minutes = Math.floor((milisecond / 1000) / 60);
          const hours = Math.floor(minutes / 60);
          const rem_mins = Math.floor(minutes % 60);
          const days = Math.floor(hours / 24);
          const rem_hrs = Math.floor(hours % 24);
          // const weeks = Math.floor(days / 7);
          // const rem_days = Math.floor(days % 7);
          // const months = Math.floor(days / 30);
          // const rem_m_all_days = Math.floor(days % 30);
          if (minutes < 1) {
              return 'just now';
          } else if (minutes < 60) {
              return minutes + 'm';
          } else if (hours <= 24) {
              if (rem_mins !== 0) {
                return hours + 'h ' + rem_mins + 'm';
              }
              return hours + 'h';
          } else if (days < 7) {
              if (rem_hrs !== 0) {
                return days + 'd ' + rem_hrs + 'h';
              }
              return  days + 'd';
          } else if (days >= 7) {
              return short_date;
          } else {
              return false;
          }
          // } else if (days >= 7) {
          //   if (rem_days !== 0) {
          //         return weeks + 'w ' + rem_days + 'd';
          //     }
          //     return weeks + 'w';
          // } else if (days >= 30) {
          //   if (rem_m_all_days !== 0) {
          //     return months + 'months ' + rem_m_all_days + 'd';
          //   }
          //   return months + 'months';
          // } else {
          //     return false;
          // }
      }
      // get all blogs offset & limit wise
      get_all_blogs(offset) {
        this.spinner.show();
        const offsett = 0;
        this.blog_offset = (offset + 1);
            this.blogService.url_getAllBlogsApi(this.authCode , offsett, this.blog_offset).
            subscribe(
              data => {
                this.Response = data;
                if (this.Response.status === 200) {
                  if (this.blog_offset === this.Response.data.length) {
                      $('#blog_view_more').show();
                  } else {
                      $('#blog_view_more').hide();
                  }
                  if (this.Response.data.length > 0) {
                    for (let i = 0; i < this.Response.data.length; i++) {
                      // tslint:disable-next-line:max-line-length
                       this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                      // tslint:disable-next-line:max-line-length
                       this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                    }
                  }
                  this.all_blog_data = this.Response.data;
                  setTimeout(() => {
                      /** spinner ends after 1 seconds */
                      this.spinner.hide();
                  }, 1000);
                } else {
                  this.responseMessage = this.Response.message;
                      /** spinner ends after 1 seconds */
                      setTimeout(() => {
                        this.spinner.hide();
                    }, 1000);
                }
              },
              error => console.log( 'Error :: ' + error )
              );
      }
    // get all keywords by keyword wise
    get_all_blog_comments(blog_id, main_index) {
            this.blogService.url_getAllBlogCommentsApi(blog_id).
            subscribe(
              data => {
                this.Response = data;
                if (this.Response.status === 200) {
                  if (this.Response.data.length > 0) {
                  for (let i = 0; i < this.Response.data.length; i++) {
                    // tslint:disable-next-line:max-line-length
                    this.Response.data[i].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].first_name, this.Response.data[i].private_key);
                    // tslint:disable-next-line:max-line-length
                    this.Response.data[i].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].last_name, this.Response.data[i].private_key);
                    // tslint:disable-next-line:max-line-length
                    if (this.Response.data[i].getAllBlogsSubComment.length > 0) {
                    for (let j = 0; j < this.Response.data[i].getAllBlogsSubComment.length; j++) {
                      // tslint:disable-next-line:max-line-length
                      this.Response.data[i].getAllBlogsSubComment[j].first_name = this.globalComponent.convertDecrypt(this.Response.data[i].getAllBlogsSubComment[j].first_name, this.Response.data[i].getAllBlogsSubComment[j].private_key);
                      // tslint:disable-next-line:max-line-length
                      this.Response.data[i].getAllBlogsSubComment[j].last_name = this.globalComponent.convertDecrypt(this.Response.data[i].getAllBlogsSubComment[j].last_name, this.Response.data[i].getAllBlogsSubComment[j].private_key);
                     }
                   }
                  }
                }
                  this.all_blog_data[main_index].getAllBlogsComment = this.Response.data;
                  this.all_blog_data[main_index].commentcnt = this.Response.data.length;
                } else {
                   this.responseMessage = this.Response.message;
                }
              },
              error => console.log( 'Error :: ' + error )
              );
        }
    // upload media gallery
    uploadImg(event) {
      this.uploadMediaNames = [];
      if (event.target.files && event.target.files.length > 0) {
        const filesAmount = event.target.files.length;
         for (let i = 0; i < filesAmount; i++) {
          $('.progress_bar_outer').show();
          this.width = 10;
          this.fileToUpload = [];
          this.fileToUpload = event.target.files[i];
          this.width = 30;
          const formData: FormData = new FormData();
          formData.append('media_data', this.fileToUpload);
          this.blogService.url_uploadMediaBlogApi(formData).
                subscribe(
                  resultArray => {
                    this.width = 50;
                    this.Response = resultArray;
                    this.width = 70;
                    if (this.Response.status === 200) {
                      this.width = 100;
                      this.uploadMediaNames.push(this.Response.data);
                    } else {
                      alert(this.Response.message);
                    }
                  },
                  error => console.log('Error :: ' + error)
            );
           }
      }
    }
    // add keywords in array
    addKeywordInput(event)  {
        if (event.which === 13) {
          const keyword_value = this.createBlogForm.controls.keywords.value;
          const index = this.outputs.indexOf(keyword_value);
            if (index === -1) {
              this.outputs.push(keyword_value);
            } else {
              // same keyword override
              this.outputs[index] = keyword_value;
            }
          this.createBlogForm.patchValue( {'keywords': null});
        }
      }
      // add keyword for select value from search dropdown
      addKeywordDropdown(value) {
          if (value !== '') {
            const index = this.outputs.indexOf(value);
              if (index === -1) {
                this.outputs.push(value);
              } else {
                // same keyword override
                this.outputs[index] = value;
              }
              this.createBlogForm.patchValue({'keywords': null});
              this.match_keywords = [];
          }
        }
      // remove keyword from keyword array
      removeKeyword(index)  {
          if (index !== '') {
            this.outputs.splice(index, 1);
          }
        }
      // get all keywords by keyword wise
      get_all_keywords(keyWord) {
        if (keyWord !== '') {
          this.blogService.url_getKeywordDetailsApi(keyWord).
          subscribe(
            data => {
              this.Response = data;
              if (this.Response.status === 200) {
               this.match_keywords = this.Response.data;
              } else {
                this.responseMessage = this.Response.message;
              }
            },
            error => console.log( 'Error :: ' + error )
            );
        } else {
          this.match_keywords = [];
        }
     }
     // convenience getter for easy access to form fields
     get f() { return this.createBlogForm.controls; }
      // convenience getter for easy access to form fields
     // get fcomment() { return this.createCommentForm.controls; }
      // Add Blog
      onSubmit() {
            this.submitted = true;
            this.responseMessage = '';
            // stop here if form is invalid
            if (this.createBlogForm.invalid) {
                    return false;
                }
              const blogTitle = this.globalComponent.convertEncrypt(this.createBlogForm.controls.blogTitle.value);
              const blogDescription = this.globalComponent.convertEncrypt(this.createBlogForm.controls.blogDescription.value);
              const blogType = this.globalComponent.convertEncrypt(this.createBlogForm.controls.blogType.value);
              const validity_days = this.globalComponent.convertEncrypt(this.createBlogForm.controls.validity_days.value);
              const reference = this.globalComponent.convertEncrypt(this.createBlogForm.controls.reference.value);

              const formData: FormData = new FormData();
              formData.append('user_id', this.userId);
              formData.append('titleBlog', blogTitle);
              formData.append('blogDescription', blogDescription);
              formData.append('blogType', blogType);
              formData.append('validity_days', validity_days);
              formData.append('keywords',  this.outputs);
              formData.append('reference', reference);
              formData.append('authCode', this.authCode);
              formData.append('uploadMedia', JSON.stringify(this.uploadMediaNames));
              this.blogService.url_createBlogApi(formData).
                    subscribe(
                      resultArray => {
                        this.Response = resultArray;
                        if (this.Response.status === 200) {
                          this.outputs = [];
                          this.uploadMediaNames = [];
                          alert(this.Response.message);
                          this.responseMessage = '';
                          this.submitted = false;
                          this.width = 0;
                          $('.progress_bar_outer').hide();
                          this.createBlogForm.reset();
                          this.get_all_blogs(this.blog_offset);
                        } else {
                          this.responseMessage = this.Response.message;
                        }
                      },
                      error => console.log('Error :: ' + error)
                );
          }
     // Add Blog Comments
      onSubmitComment(parent_comment_id, blog_id, main_index, index) {
        this.com_submitted = true;
        this.responseComMessage = '';
        let comment_text = '';
            if (parent_comment_id  !== '' ) {
                comment_text = this.globalComponent.convertEncrypt($('#comment_id_' + index).val());
                if (comment_text === '') {
                    return false;
                }
             } else {
              comment_text = this.globalComponent.convertEncrypt($('#parent_comment_id_' + main_index).val());
              if (comment_text === '') {
                    return false;
                }
              // comment_text = this.globalComponent.convertEncrypt(this.createCommentForm.controls.comment_text.value);
            }
          const formData: FormData = new FormData();
          formData.append('user_id', this.userId);
          formData.append('blog_id', blog_id);
          formData.append('comment_text', comment_text);
          formData.append('authCode', this.authCode);
          formData.append('parent_comment_id', parent_comment_id);
          this.blogService.url_blogCommentApi(formData).
                subscribe(
                  resultArray => {
                    this.Response = resultArray;
                    if (this.Response.status === 200) {
                      alert(this.Response.message);
                      this.responseComMessage = '';
                      this.com_submitted = false;
                      if (parent_comment_id  !== '' ) {
                        $('#comment_id_' + index).val('');
                      } else {
                        $('#parent_comment_id_' + main_index).val('');
                      }
                      this.get_all_blog_comments(blog_id, main_index);
                    } else {
                      this.responseComMessage = this.Response.message;
                    }
                  },
                  error => console.log('Error :: ' + error)
            );
      }
      // Update Blog Comments
      onSetCommentValue(parent_comment_id, blog_comment_id, value, index) {
        this.is_comment_id =  '';
        this.is_comment_type = '';
        this.is_comment_index = '';
          if (parent_comment_id  !== '' ) {
            $('#comment_id_' + index).val(value);
            this.is_comment_type = '2';
        } else {
            $('#parent_comment_id_' + index).val(value);
            this.is_comment_type = '1';
        }
        this.is_comment_id = blog_comment_id;
        this.is_comment_index = index;
      }
      // Update Blog Comments
      onUpdateComment(blog_id, main_index, index) {
        this.responseComMessage = '';
        let comment_text = '';
            if (index  !== '' ) {
                comment_text = this.globalComponent.convertEncrypt($('#comment_id_' + index).val());
                if (comment_text === '') {
                    return false;
                }
             } else {
              comment_text = this.globalComponent.convertEncrypt($('#parent_comment_id_' + main_index).val());
              if (comment_text === '') {
                    return false;
                }
            }
          this.is_comment_id = this.globalComponent.convertEncrypt(this.is_comment_id);
          const formData: FormData = new FormData();
          formData.append('user_id', this.userId);
          formData.append('comment_id', this.is_comment_id);
          formData.append('comment_text', comment_text);
          formData.append('authCode', this.authCode);
          this.blogService.url_updateBlogCommentApi(formData).
                subscribe(
                  resultArray => {
                    this.Response = resultArray;
                    if (this.Response.status === 200) {
                      alert(this.Response.message);
                      this.responseComMessage = '';
                      this.is_comment_id =  '';
                      this.is_comment_type = '';
                      this.is_comment_index = '';
                      if (index  !== '' ) {
                        $('#comment_id_' + index).val('');
                      } else {
                        $('#parent_comment_id_' + main_index).val('');
                      }
                       this.get_all_blog_comments(blog_id, main_index);
                    } else {
                      this.responseComMessage = this.Response.message;
                    }
                  },
                  error => console.log('Error :: ' + error)
            );
      }
       // Add Blog Likes
      addBlogLike(blog_id, index) {
              const formData: FormData = new FormData();
              formData.append('user_id', this.userId);
              formData.append('blog_id', blog_id);
              formData.append('authCode', this.authCode);
              this.blogService.url_blogLikeApi(formData).
                  subscribe(
                      resultArray => {
                        this.Response = resultArray;
                        if (this.Response.status === 200 || this.Response.status === 201) {
                          this.responseComMessage = '';
                          if (this.Response.status === 200) {
                            // $('#like_id_' + index).removeClass('btn btn-default');
                            // $('#like_id_' + index).addClass('btn btn-primary');
                            this.all_blog_data[index].blogUserLike = 1;
                          }
                          if (this.Response.status === 201) {
                            // $('#like_id_' + index).removeClass('btn btn-primary');
                            // $('#like_id_' + index).addClass('btn btn-default');
                            this.all_blog_data[index].blogUserLike = 0;
                          }
                          this.all_blog_data[index].likescnt = this.Response.data;
                        } else {
                          this.responseComMessage = this.Response.message;
                        }
                      },
                      error => console.log('Error :: ' + error)
                );
          }
}
