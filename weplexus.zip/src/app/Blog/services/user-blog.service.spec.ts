import { TestBed, inject } from '@angular/core/testing';

import { UserBlogService } from './user-blog.service';

describe('UserBlogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserBlogService]
    });
  });

  it('should be created', inject([UserBlogService], (service: UserBlogService) => {
    expect(service).toBeTruthy();
  }));
});
