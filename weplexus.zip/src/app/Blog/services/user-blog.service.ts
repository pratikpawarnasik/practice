import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { Http, Response } from '@angular/http';
import { CookieService } from 'ngx-cookie-service';
import { GlobalsService } from '../../globals.service';

@Injectable({
  providedIn: 'root'
})
export class UserBlogService {
  constructor(private http: Http, private globals: GlobalsService, private cookieService: CookieService) { }
  userId = this.cookieService.get('userId');
  userEmail = this.cookieService.get('userEmail');
  userFirstName = this.cookieService.get('userFirstName');
  userLastName = this.cookieService.get('userLastName');
  userType = this.cookieService.get('userType');
  authCode = this.cookieService.get('authCode');
  privateKey = this.cookieService.get('privateKey');

  // error handler
  private handleError(error: Response) {
      return 'error';
    }
  // create Blog
  url_createBlogApi(data) {
    return this.http
    .post(this.globals.createBlogAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
  // Blog images/videos upload
  url_uploadMediaBlogApi(data) {
    return this.http
    .post(this.globals.uploadMediaBlogAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
  // Get all Blog Keyword keyword wise
  url_getKeywordDetailsApi(keyword) {
      return this.http
      .get(this.globals.getKeywordsAPIUrl + '/' + keyword).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
    }
  // Get all Blogs offset & limit wise
    url_getAllBlogsApi(auth_code, offset, limit) {
        return this.http
        .get(this.globals.getAllBlogAPIUrl + '/' + auth_code + '/' + offset + '/' + limit).pipe(
        map((response: Response) => {
          return response.json();
        }),
        catchError(this.handleError));
    }
    // Add Blog Comment
    url_blogCommentApi(data) {
      return this.http
      .post(this.globals.addBlogCommentAPIUrl, data).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
    }
   // Update Blog Comment
    url_updateBlogCommentApi(data) {
          return this.http
          .post(this.globals.updateBlogCommentAPIUrl, data).pipe(
          map((response: Response) => {
            return response.json();
          }),
          catchError(this.handleError));
        }
     // Get all Blog Comments
     url_getAllBlogCommentsApi(blog_id) {
      return this.http
      .get(this.globals.getBlogCommentAPIUrl + '/' + blog_id).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
    }
    // Blog add like
    url_blogLikeApi(data) {
      return this.http
      .post(this.globals.addBlogLikeAPIUrl, data).pipe(
      map((response: Response) => {
        return response.json();
      }),
      catchError(this.handleError));
    }
}
