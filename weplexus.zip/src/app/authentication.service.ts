import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, Route } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { UserServiceService } from './user-service.service';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService implements CanActivate {

  // tslint:disable-next-line:max-line-length
  constructor(private _router: Router, private cookieService: CookieService, private authService: UserServiceService) {}
  // login parameters
  log_type =  'pgBBuJxpJVsSN27GFgG0ow!!'; // 'user-profile'
  log_value =  'woxj5Xdksr+m7zlaveKsmg!!'; // 'default';
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.authService.isLoggedUser()) {
        return true;
    }
    // navigate to login page
    this._router.navigate(['/login/'  + this.log_type + this.log_value]);
    // you can save redirect url so after authing we can move them back to the page they requested
    return false;
  }
  // User Logout
  logOut(log_type1, log_value1) {
    this.cookieService.delete('userId');
    this.cookieService.delete('userEmail');
    this.cookieService.delete('userFirstName');
    this.cookieService.delete('userLastName');
    this.cookieService.delete('userType');
    this.cookieService.delete('authCode');
    this.cookieService.delete('privateKey');
    this._router.navigate(['/login/' + log_type1 + '/' + log_value1]);
  }
}
