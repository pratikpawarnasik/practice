import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalsService {
  constructor() { }
  baseAPIUrl = 'http://localhost/lara_test_api/public/api';
  userRegistrationAPIUrl = this.baseAPIUrl + '/user/create';
  userProfileUpdateAPIUrl = this.baseAPIUrl + '/user/update';
  userProfileDetailsAPIUrl = this.baseAPIUrl + '/user/get_single_user';
  userLoginAPIUrl = this.baseAPIUrl + '/user/login';
  userVerifyAPIUrl = this.baseAPIUrl + '/user/verify/';
  userForgotAPIUrl = this.baseAPIUrl + '/user/forgot';
  checkResetPassLinkAPIUrl = this.baseAPIUrl + '/user/check_reset_pass_link/';
  resetPassLinkAPIUrl = this.baseAPIUrl + '/user/reset';
  changePassLinkAPIUrl = this.baseAPIUrl + '/user/change_password';
  createBlogAPIUrl = this.baseAPIUrl + '/blog/create';
  getKeywordsAPIUrl = this.baseAPIUrl + '/blog/getSearchKeyword';
  uploadMediaBlogAPIUrl = this.baseAPIUrl + '/blog/uploadBlogMedia';
  getAllBlogAPIUrl = this.baseAPIUrl + '/blog/get_all_blogs';
  addBlogCommentAPIUrl = this.baseAPIUrl + '/blog/add_blog_comment';
  updateBlogCommentAPIUrl = this.baseAPIUrl + '/blog/update_blog_comment';
  getBlogCommentAPIUrl = this.baseAPIUrl + '/blog/get_blog_comment';
  addBlogLikeAPIUrl = this.baseAPIUrl + '/blog/add_blog_like';
  addClassRoomAPIUrl = this.baseAPIUrl + '/classroom/create';
  getAllClassRoomAPIUrl = this.baseAPIUrl + '/classroom/get_all_classrooms';
  getSingleClassRoomAPIUrl = this.baseAPIUrl + '/classroom/get_single_classroom';
  getSingleUserClassRoomAPIUrl = this.baseAPIUrl + '/classroom/get_single_user_classroom';
  joinClassRoomAPIUrl = this.baseAPIUrl + '/classroom/join';
  getClassRoomKeywordsAPIUrl = this.baseAPIUrl + '/classroom/getSearchKeyword';
  getClassRoomJoinRequestAPIUrl = this.baseAPIUrl + '/classroom/getClassRoomJoinRequest';
  updateClassRoomJoinRequestAPIUrl = this.baseAPIUrl + '/classroom/updateClassRoomJoinRequest';
  checkClassRoomMemberAPIUrl = this.baseAPIUrl + '/classroom/checkClassRoomMember';
  getSearchEmailsAPIUrl = this.baseAPIUrl + '/classroom/getSearchEmail';
  verifyInviteClassRoomMemberAPIUrl = this.baseAPIUrl + '/classroom/verifyInviteClassRoomMember';
  checkInviteClassRoomMemberAPIUrl = this.baseAPIUrl + '/classroom/checkInviteClassRoomMember';

  // classroom discussion
  createDiscussionAPIUrl = this.baseAPIUrl + '/classroom/create_classroom_discussion';
  uploadMediaDiscussionAPIUrl = this.baseAPIUrl + '/classroom/uploadClassroomDiscussionMedia';
  getAllDiscussionAPIUrl = this.baseAPIUrl + '/classroom/get_all_classroom_discussions';
  addDiscussionCommentAPIUrl = this.baseAPIUrl + '/classroom/add_classroom_discussion_comment';
  updateDiscussionCommentAPIUrl = this.baseAPIUrl + '/classroom/update_classroom_discussion_comment';
  getDiscussionCommentAPIUrl = this.baseAPIUrl + '/classroom/get_classroom_discussion_comment';
  addDiscussionLikeAPIUrl = this.baseAPIUrl + '/classroom/add_classroom_discussion_like';
  inviteUserForClassRoomAPIUrl = this.baseAPIUrl + '/classroom/invite_users_for_classroom';
}
