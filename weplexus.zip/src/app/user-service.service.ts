import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { Http, Response, Headers } from '@angular/http';
import { CookieService } from 'ngx-cookie-service';
import { GlobalsService } from './globals.service';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  constructor(private http: Http, private globals: GlobalsService, private cookieService: CookieService) { }
  userId = this.cookieService.get('userId');
  userEmail = this.cookieService.get('userEmail');
  userFirstName = this.cookieService.get('userFirstName');
  userLastName = this.cookieService.get('userLastName');
  userType = this.cookieService.get('userType');
  authCode = this.cookieService.get('authCode');
  privateKey = this.cookieService.get('privateKey');
  // headers = new Headers();

    // error handler
    private handleError(error: Response) {
      return 'error';
    }
    // isLoggedUser
    isLoggedUser() {
      const cookieUserIdExists: boolean = this.cookieService.check('userId');
      if (cookieUserIdExists) {
        return true;
      }
        return false;
    }
  // create Candidate Password
  url_registerUserApi(data) {
    return this.http
    .post(this.globals.userRegistrationAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
 }
  // create Candidate Password
  url_updateProfileUserApi(data) {
    // this.headers.append('authCode', this.authCode);
    // this.headers.append('Content-Type', 'application/json');
    // this.headers.append('Access-Control-Allow-Origin', '*');
    // this.headers.append('Access-Control-Allow-Headers', 'Cache-Control');

    return this.http
    // tslint:disable-next-line:max-line-length
    .post(this.globals.userProfileUpdateAPIUrl, data).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
   }
  private newMethod(): string {
    return 'POST';
  }

   // Get Single User Details
  url_getProfileDetailsUserApi(id, auth_code) {
    return this.http
    .get(this.globals.userProfileDetailsAPIUrl + '/' + id + '/' + auth_code).pipe(
    map((response: Response) => {
      return response.json();
    }),
    catchError(this.handleError));
  }
 // User Login
 url_loginUserApi(data) {
  return this.http
  .post(this.globals.userLoginAPIUrl, data).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
 }
 // create Candidate Password
 url_verifyUserApi(id) {
  return this.http
  .get(this.globals.userVerifyAPIUrl + id).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
 }
// create forget Password
url_forgetPasswordUserApi(data) {
  return this.http
  .post(this.globals.userForgotAPIUrl, data).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
 }
 // create forget Password
 url_checkResetPassLinkUserApi(reset_code) {
  return this.http
  .get(this.globals.checkResetPassLinkAPIUrl + reset_code).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
 }
 // create reset Password
url_forgetResetPasswordUserApi(data) {
  return this.http
  .post(this.globals.resetPassLinkAPIUrl, data).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
 }
  // change reset Password
url_changePasswordUserApi(data) {
  return this.http
  .post(this.globals.changePassLinkAPIUrl, data).pipe(
  map((response: Response) => {
    return response.json();
  }),
  catchError(this.handleError));
 }
}
